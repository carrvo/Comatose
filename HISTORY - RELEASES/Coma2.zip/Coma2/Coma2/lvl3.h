#ifndef LVL3_H
#define LVL3_H

extern void crackloclvl3(int w, int h);
extern void inside3(char board[], int w);
extern void ploc3();
extern void cloc3();
extern bool printboard3(bool open);
extern bool afterin3(char board[], int w, int fin);
extern bool nxtlvl3();
extern void breset3();
extern void callhturn3();
extern void printp3(char board[]);
extern void printc3(char board[], int w);
extern void printb3(char board[]);
extern void bombconv3(int bombs2);
extern void bkeep4();

#endif