#ifndef LVL2_H
#define LVL2_H

extern void crackloclvl2(int w);
extern void inside2(char board[], int w);
extern bool printboard2(bool open);
extern bool afterin2(char board[], int w, int fin);
extern bool nxtlvl2();
extern void breset2();
extern void callhturn2();
extern void printp2(char board[]);
extern void printc2(char board[], int w);
extern void printb2(char board[]);
extern void bombconv2(int bombs2);
extern void bkeep3();

#endif