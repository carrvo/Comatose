from __future__ import absolute_import
import sys
import os
pathextend = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(1, pathextend)
from setlvl import comatose
