#!/bin/python3
from pyComa import comatose
while(comatose()):
    pass