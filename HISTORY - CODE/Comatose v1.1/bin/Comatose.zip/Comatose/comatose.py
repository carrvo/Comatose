#!/bin/python
from __future__ import absolute_import
from pyComa import comatose
while(comatose()):
    pass